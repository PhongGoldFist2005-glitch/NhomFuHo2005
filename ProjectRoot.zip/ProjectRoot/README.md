# NhomFuHo2005
Chủ đề của bài tập lớn là phát triển trò chơi Arkanoid, một game kinh điển thuộc thể loại phá gạch. Nhiệm vụ của người chơi là điều khiển thanh đỡ (Paddle) để giữ bóng không rơi xuống và phá vỡ toàn bộ gạch trên màn hình.
