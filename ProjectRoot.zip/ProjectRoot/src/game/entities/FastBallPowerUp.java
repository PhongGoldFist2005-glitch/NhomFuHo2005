package game.entities;

//public class FastBallPowerUp extends PowerUp {
//    public FastBallPowerUp(){
//
//    }
//}