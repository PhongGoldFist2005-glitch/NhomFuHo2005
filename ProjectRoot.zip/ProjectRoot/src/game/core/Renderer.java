package game.core;

import javax.swing.JPanel;

public class Renderer extends JPanel {
    public Renderer() {
        // Pass
    }

}